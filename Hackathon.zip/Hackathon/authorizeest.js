// Import cookie parser function
const parseCookies = require("./parsecookies.js");

// Import database functions
const database = require("./database.js");

// Authorization middleware function for access regulation
async function authorize(request, response, next) {
  // Enable register and login
  if (request.path === "/register" || request.path === "/login") {
    return next();
  }

  // Get the sessionID from the request cookies
  const { sessionID } = parseCookies(request.headers.cookie);

  // If it's missing, respond with an error
  if (!sessionID) {
    return response.status(401).json({ success: false, message: "Unauthorized", unauthorizedError: true });
  }

  // Get establishment
  const establishment = await database.establishmentForSessionID(sessionID);

  // If no establishment, respond with an error
  if (!establishment) {
    return response.status(401).json({ success: false, message: "Unauthorized", unauthorizedError: true });
  }

  // Set establishment on request object
  request.establishment = establishment;

  // Call next()
  return next();
}

// Export the function
module.exports = authorize;

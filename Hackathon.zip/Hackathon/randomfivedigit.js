// A function generating a random five digit code
function randomCode() {
  // Digits
  let digits = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  digits = digits.split("");

  // Final
  let final = "";

  for (let i = 0; i < 5; i++) {
    final += digits[Math.floor(Math.random() * digits.length)];
  }

  return final;
}

// Export function
module.exports = randomCode;
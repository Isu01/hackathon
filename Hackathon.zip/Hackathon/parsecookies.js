// Cookie parser function
function parseCookies(cookies) {
  // If no cookies, return an empty object
  if (!cookies) {
    return {};
  }

  // Separate the cookies
  cookies = cookies.split(";");

  // Remove any whitespaces and separate each individual cookie into key and value
  cookies = cookies.map((cookie) => cookie.trim().split("="));

  // Create an object from the array
  cookies = cookies.reduce((cookies, cookie) => {
    // Destructure the subarray
    const [key, value] = cookie;
    // Set property on the object
    cookies[key] = value;

    // Return the updated object
    return cookies;
  }, {})

  // Return final cookies object
  return cookies;
}

// Export function
module.exports = parseCookies;

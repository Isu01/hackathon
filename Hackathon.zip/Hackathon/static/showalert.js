
// Function for showing alert
// Parameters
// title: String, the alert's title
// success: Boolean, indicates whether the alert should be green or red
// redirect: String, the path where the page should be redirected
function showAlert(title, success, redirect) {
  // Select content
  const content = document.body;
  // Create alert
  const alert = document.createElement("div");
  alert.classList.add("alert");
  alert.innerHTML = `
  <div class="alert-center">
    <p>Alert Title</p>
  </div>
  `;

  // Hide all the other alerts
  const alerts = content.querySelectorAll(".alert");
  alerts.forEach((alert) => {
    alert.classList.remove("show-alert");
  });

  // Add alert
  content.appendChild(alert);
  // Select alert title
  const alertTitle = alert.querySelector("p");

  // Set title
  alertTitle.textContent = title;
  // Set color
  if (success) {
    alert.classList.add("success-alert");
  } else {
    alert.classList.remove("success-alert");
  }
  // Show alert
  alert.classList.add("show-alert");

  // Hide alert after 2 seconds
  setTimeout(() => {
    alert.classList.remove("show-alert");
  }, 2000);

  // If the redirect parameter has any value, redirect there, and disable user interaction
  if (redirect) {
    // Redirect after the specified time
    setTimeout(() => {
      location.href = redirect;
    }, 600);
    
    // Disable user interaction
    document.body.style.pointerEvents = "none";
  }
}

// Export function
export default showAlert;
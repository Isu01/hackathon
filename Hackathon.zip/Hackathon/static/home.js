// Import sendRequest function to send HTTP Requests
import sendRequest from "/sendrequest.js";


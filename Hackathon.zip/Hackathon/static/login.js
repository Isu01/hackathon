// Import sendRequest function to send HTTP Requests
import sendRequest from "/sendrequest.js";

// Import showalert function
import showAlert from "/showalert.js";


// Select form
const form = document.querySelector(".login-form");
// Select inputs
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
// Select options
const estOption = document.querySelector(".option.est");
const memOption = document.querySelector(".option.mem");

let selectedOption = "est";

estOption.addEventListener("click", () => {
  selectedOption = "est";
  estOption.classList.add("selected");
  memOption.classList.remove("selected");
});

memOption.addEventListener("click", () => {
  selectedOption = "mem";
  memOption.classList.add("selected");
  estOption.classList.remove("selected");
});


// Form submission
form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const data = {
    email: emailInput.value,
    password: passwordInput.value
  }

  const result = await sendRequest(`/api/${selectedOption}/login`, "POST", data);

  if (result.success) {
    showAlert("Success", true, "/data");
  } else {
    if (result.unauthorizedError) {
      showAlert("Wrong details", false, undefined);
    } else {
      showAlert("Error", false, undefined);
    }
  }
});
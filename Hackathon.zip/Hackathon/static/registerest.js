// Import sendRequest function to send HTTP Requests
import sendRequest from "/sendrequest.js";

// Import showalert function
import showAlert from "/showalert.js";

// Select form
const form = document.querySelector(".register-form");
// Select inputs
const inputs = document.querySelectorAll("input");

// Form submission
form.addEventListener("submit", async (event) => {
  event.preventDefault();

  // Get data from inputs
  let data = {};
  inputs.forEach((input) => {
    data[input.id] = input.value;
  });

  data.usesWater = true;
  data.usesElectricity = true;
  data.usesGas = true;

  const result = await sendRequest("/api/est/register", "POST", data);

  if (result.success) {
    showAlert("Success", true, "/data");
  } else {
    if (result.emailError) {
      showAlert("Email is in use", false, undefined);
    } else {
      showAlert("Error", false, undefined);
    }
  }
});
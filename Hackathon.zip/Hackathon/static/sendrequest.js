// Function for sending HTTP Requests
async function sendRequest(url, method, data) {
  try {
    let result = await fetch(url, {
      headers: data ?
        { 'Content-Type': 'application/json' }
        : {},
      method: method,
      body: JSON.stringify(data)
    });
    result = await result.json();
    
    return result;
  } catch (error) {
    console.log(error);
    return {};
  }
}

// Export function
export default sendRequest;
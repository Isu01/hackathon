// API ROUTER

// Import Express
const express = require("express");
// Initialize router instance
const router = express.Router();

// Import controller
const controller = require("../controllers/api.js");

// =================
// BASE PATH: /api
// =================

// PATHS

// ESTABLISHMENTS
// Authorization
const authorizeEst = require("../authorizeest.js");
router.use("/est", authorizeEst);
// Router
const routerEst = require("./est.js");
router.use("/est", routerEst);

// MEMBERS
// Authorization
const authorizeMem = require("../authorizemem.js");
router.use("/mem", authorizeMem);
// Router
const routerMem = require("./mem.js");
router.use("/mem", routerMem);

// Export the router
module.exports = router;

// ESTABLISHMENT ROUTER

// Import Express
const express = require("express");
// Initialize router instance
const router = express.Router();

// Import controller
const controller = require("../controllers/est.js");

// ===================
// BASE PATH: /api/est
// ===================

// PATHS

// Register
router.post("/register", controller.register);

// Login
router.post("/login", controller.login);

// Log Data
router.post("/logdata", controller.logData);

// Get Member Info
router.get("/memberinfo", controller.memberInfo);

// Handle Members
router.post("/handlemembers", controller.handleMembers);

// Export the router
module.exports = router;

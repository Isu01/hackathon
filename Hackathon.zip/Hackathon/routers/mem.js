// MEMBER ROUTER

// Import Express
const express = require("express");
// Initialize router instance
const router = express.Router();

// Import controller
const controller = require("../controllers/mem.js");

// ===================
// BASE PATH: /api/mem
// ===================

// PATHS

// Register
router.post("/register", controller.register);

// Login
router.post("/login", controller.login);

// Get Membership Info
router.get("/membershipinfo", controller.membershipInfo);

// Handle Memberships
router.post("/handlememberships", controller.handleMemberships);

// Export the router
module.exports = router;

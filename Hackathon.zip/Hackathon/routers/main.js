// MAIN ROUTER

// Import Express
const express = require("express");
// Initialize router instance
const router = express.Router();

// Import controller
const controller = require("../controllers/main.js");

// ===============
// BASE PATH: /
// ===============

// PATHS

// Home Page
router.get("/", controller.home);

// Data Page
router.get("/data", controller.data);

// Register Page
router.get("/register", controller.register);

// Login Page
router.get("/login", controller.login);


// Export the router
module.exports = router;

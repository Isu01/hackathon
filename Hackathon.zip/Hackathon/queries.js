// Queries for database access

// Add establishment
// 1. ?: id
// 2. ?: email
// 3. ?: password
// 4. ?: name
// 5. ?: type
// 6. ?: area
// 7. ?: country
// 8. ?: place
// 9. ?: uses water
// 10. ?: uses electricity
// 11. ?: uses gas
// 12. ?: session id
const addEstablishment = `
INSERT INTO establishments
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
`;

// Add member
// 1. ?: id
// 2. ?: email
// 3. ?: password
// 4. ?: name
// 5. ?: member of
// 6. ?: session id
const addMember = `
INSERT INTO members
VALUES (?, ?, ?, ?, ?, ?);
`;

// Add log
// 1. ?: establishment id
// 2. ?: total water
// 3. ?: total electricity
// 4. ?: total gas
const addLog = `
INSERT INTO logs
VALUES (?, DEFAULT, ?, ?, ?);
`;

// Establishment with id
// 1. ?: id
const establishmentWithID = `
SELECT
  id,
  email,
  name,
  type,
  area,
  country,
  place,
  useswater AS usesWater,
  useselectricity AS usesElectricity,
  usesgas AS usesGas
FROM establishments
WHERE id = ?;
`;

// Establishment with session id
// 1. ?: session id
const establishmentWithSessionID = `
SELECT
  id,
  email,
  name,
  type,
  area,
  country,
  place,
  useswater AS usesWater,
  useselectricity AS usesElectricity,
  usesgas AS usesGas
FROM establishments
WHERE sessionid = ?;
`;

// Establishment with email
// 1. ?: email
const establishmentWithEmail = `
SELECT
  id,
  email,
  name,
  type,
  area,
  country,
  place,
  useswater AS usesWater,
  useselectricity AS usesElectricity,
  usesgas AS usesGas
FROM establishments
WHERE email = ?;
`;

// Member with session id
// 1. ?: session id
const memberWithSessionID = `
SELECT
  id,
  email,
  name,
  memberof AS membership
FROM members
WHERE sessionid = ?;
`;

// Member with email
// 1. ?: member email
const memberWithEmail = `
SELECT
  id,
  name,
  email,
  memberof AS membership
FROM members
WHERE email = ?;
`;

// Establishment login
// 1. ?: email
// 2. ?: password
const establishmentLogin = `
SELECT
  id,
  email,
  name
FROM establishments
WHERE email = ? AND password = ?;
`;

// Update establishment session id
// 1. ?: session id
// 2. ?: id
const updateEstablishmentSessionID = `
UPDATE establishments
SET sessionid = ?
WHERE id = ?;
`;

// Member login
// 1. ?: email
// 2. ?: password
const memberLogin = `
SELECT
  id,
  email,
  name
FROM members
WHERE email = ? AND password = ?;
`;

// Update member session id
// 1. ?: session id
// 2. ?: id
const updateMemberSessionID = `
UPDATE members
SET sessionid = ?
WHERE id = ?;
`;

// Members of establishment
// 1. ?: establishment id
const membersOfEstablishment = `
SELECT
  email,
  name
FROM members
WHERE memberof REGEXP ?;
`;

// Invites of establishment
// 1. ?: establishment id
const invitesOfEstablishment = `
SELECT
  senderid AS senderID,
  inviteeemail AS inviteeEmail
FROM invites
WHERE senderid = ? AND accepted = FALSE;
`;

// Existing invite
// 1. ?: sender id
// 2. ?: invitee email
const existingInvite = `
SELECT
  senderid,
  inviteeemail
FROM invites
WHERE senderid = ? AND inviteeemail = ?;
`;

// Add invite
// 1. ?: sender id
// 2. ?: invitee email
const addInvite = `
INSERT INTO invites
VALUES (?, ?, FALSE, FALSE);
`;

// Withdraw invite
// 1. ?: sender id
// 2. ?: invitee email
const withdrawInvite = `
DELETE FROM invites
WHERE senderid = ? AND inviteeemail = ? AND accepted = FALSE;
`;

// Update member membership
// 1. ?: membership
// 2. ?: member email
const updateMemberMembership = `
UPDATE members
SET memberof = ?
WHERE email = ?;
`;

// Establishments for member
// 1. ?: member id
const establishmentsForMember = `
SELECT
  e.id,
  e.name
FROM members m
JOIN establishments e
ON m.memberof REGEXP e.id
WHERE m.id = ?;
`;

// Invites for member
// 1. ?: member email
const invitesForMember = `
SELECT
  e.id,
  e.name
FROM invites i
JOIN establishments e
ON i.senderid = e.id
WHERE i.inviteeemail = ?;
`;

// Update invite to accepted
// 1. ?: sender id
// 2. ?: invitee email
const updateInviteToAccepted = `
UPDATE invites
SET accepted = TRUE
WHERE senderid = ? AND inviteeemail = ?;
`;

// Export queries
module.exports = {
  addEstablishment,
  addMember,
  addLog,
  establishmentWithID,
  establishmentWithSessionID,
  establishmentWithEmail,
  memberWithSessionID,
  memberWithEmail,
  establishmentLogin,
  updateEstablishmentSessionID,
  memberLogin,
  updateMemberSessionID,
  membersOfEstablishment,
  invitesOfEstablishment,
  existingInvite,
  addInvite,
  withdrawInvite,
  updateMemberMembership,
  establishmentsForMember,
  invitesForMember,
  updateInviteToAccepted
}

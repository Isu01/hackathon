// Import cookie parser function
const parseCookies = require("./parsecookies.js");

// Import database functions
const database = require("./database.js");

// Authorization middleware function for access regulation
async function authorize(request, response, next) {
  // Enable access to Main Site, Login Page, Register Page and the API
  // For the API, authorization is handled later
  if (request.path === "/" || request.path === "/login" || request.path === "/register" || /\/api\//.test(request.path)) {
    return next();
  }

  // Get the sessionID and profileType from the request cookies
  const { sessionID, profileType } = parseCookies(request.headers.cookie);

  // If any of them is missing, redirect to the login page
  if (!sessionID || !profileType) {
    return response.redirect("/login");
  }

  // ==================================
  // CHECK IF THERE IS ACCESS

  // Initialize establishment and member
  let establishment;
  let member;

  // Get relevant data
  // Establishment
  if (profileType === "establishment") {
    // Get establishment
    establishment = await database.establishmentForSessionID(sessionID);
  }

  // Member
  if (profileType === "member") {
    // Get member
    member = await database.memberForSessionID(sessionID);
  }

  
  // If none exists, redirect to login
  if (!establishment && !member) {
    return response.redirect("/login");
  }

  // Set them on the request object
  request.establishment = establishment;
  request.member = member;

  // Call next()
  return next();
}

// Export the function
module.exports = authorize;

// Import MySQL
const mysql = require("mysql2");

// TEST SETUP
// process.env.MYSQL_HOST = "localhost";
// process.env.MYSQL_USER = "root";
// process.env.MYSQL_PASSWORD = "password";
// process.env.MYSQL_DATABASE = "hackathon";

// Create a pool for queries
// We choose the promise version so that we can use async await
const pool = mysql.createPool({
  host: process.env.MYSQL_HOST,
  user: process.env.MYSQL_USER,
  password: process.env.MYSQL_PASSWORD,
  database: process.env.MYSQL_DATABASE
}).promise();


// QUERIES
const queries = require("./queries.js");

// ====================
// DATABASE FUNCTIONS
// ====================

// Add establishment
async function addEstablishment(id, email, password, name, type, area, country, place, usesWater, usesElectricity, usesGas, sessionID) {
  try {
    // Add establishment
    const success = await query(queries.addEstablishment, [id, email, password, name, type, area, country, place, usesWater, usesElectricity, usesGas, sessionID], false);

    return success ? true : false;
  } catch (error) {
    console.error(error);
    return false;
  }
}

// Add member
async function addMember(id, email, password, name, memberOf, sessionID) {
  try {
    // Add member
    const success = await query(queries.addMember, [id, email, password, name, memberOf, sessionID], false);

    return success ? true : false;
  } catch (error) {
    console.error(error);
    return false;
  }
}

// Log data
async function logData(id, totalWater, totalElectricity, totalGas) {
  try {
    // Log data
    const success = await query(queries.addLog, [id, totalWater, totalElectricity, totalGas], false);

    return success ? true : false;
  } catch (error) {
    console.error(error);
    return false;
  }
}

// Establishment for session id
async function establishmentForSessionID(sessionID) {
  try {
    // Get establishment
    const establishment = await query(queries.establishmentWithSessionID, [sessionID], true);

    // Transform values to wanted data type
    establishment.area = Number(establishment.area);
    establishment.usesWater = establishment.usesWater == 1 ? true : false;
    establishment.usesElectricity = establishment.usesElectricity == 1 ? true : false;
    establishment.usesGas = establishment.usesGas == 1 ? true : false;

    return establishment;
  } catch (error) {
    console.error(error);
    return undefined;
  }
}

// Establishment for email
async function establishmentForEmail(email) {
  try {
    // Get establishment
    const establishment = await query(queries.establishmentWithEmail, [email], true);

    return establishment;
  } catch (error) {
    console.error(error);
    return undefined;
  }
}

// Member for session id
async function memberForSessionID(sessionID) {
  try {
    // Get member
    const member = await query(queries.memberWithSessionID, [sessionID], true);

    // Format membership
    if (member.membership) {
      member.membership = member.membership.split("|");
    } else {
      member.membership = [];
    }

    return member;
  } catch (error) {
    console.error(error);
    return undefined;
  }
}

// Member for email
async function memberForEmail(email) {
  try {
    // Get member
    const member = await query(queries.memberWithEmail, [email], true);

    // Format membership
    if (member.membership) {
      member.membership = member.membership.split("|");
    } else {
      member.membership = [];
    }

    return member;
  } catch (error) {
    console.error(error);
    return undefined;
  }
}

// Establishment for login
async function establishmentForLogin(email, password) {
  try {
    // Get establishment
    const establishment = await query(queries.establishmentLogin, [email, password], true);

    return establishment;
  } catch (error) {
    console.error(error);
    return undefined;
  }
}

// Update establishment session id
async function updateEstablishmentSessionID(id, sessionID) {
  try {
    // Update session id
    const success = await query(queries.updateEstablishmentSessionID, [sessionID, id], false);

    return success ? true : false;
  } catch (error) {
    console.error(error);
    return false;
  }
}

// Member for login
async function memberForLogin(email, password) {
  try {
    // Get member
    const member = await query(queries.memberLogin, [email, password], true);

    return member;
  } catch (error) {
    console.error(error);
    return undefined;
  }
}

// Update member session id
async function updateMemberSessionID(id, sessionID) {
  try {
    // Update session id
    const success = await query(queries.updateMemberSessionID, [sessionID, id], false);

    return success ? true : false;
  } catch (error) {
    console.error(error);
    return false;
  }
}

// Members of establishment
async function membersOfEstablishment(id) {
  try {
    // Get members
    const members = await query(queries.membersOfEstablishment, [id], false);

    return members;
  } catch (error) {
    console.error(error);
    return undefined;
  }
}

// Invites of establishment
async function invitesOfEstablishment(id) {
  try {
    // Get invites
    const invites = await query(queries.invitesOfEstablishment, [id], false);

    return invites;
  } catch (error) {
    console.error(error);
    return undefined;
  }
}

// Existing invite
async function existingInvite(senderID, inviteeEmail) {
  try {
    // Get invite
    const invite = await query(queries.existingInvite, [senderID, inviteeEmail], true);

    return invite;
  } catch (error) {
    console.error(error);
    return undefined;
  }
}

// Add invite
async function addInvite(senderID, inviteeEmail) {
  try {
    // Add invite
    const success = await query(queries.addInvite, [senderID, inviteeEmail], false);

    return success ? true : false;
  } catch (error) {
    console.error(error);
    return false;
  }
}

// Withdraw invite
async function withdrawInvite(senderID, inviteeEmail) {
  try {
    // Withdraw invite
    const success = await query(queries.withdrawInvite, [senderID, inviteeEmail], false);

    return success ? true : false;
  } catch (error) {
    console.error(error);
    return false;
  }
}

// Update member membership
async function updateMemberMembership(email, membership) {
  try {
    // Update member membership
    const success = await query(queries.updateMemberMembership, [membership, email], false);

    return success ? true : false;
  } catch (error) {
    console.error(error);
    return false;
  }
}

// Establishments for member
async function establishmentsForMember(id) {
  try {
    // Get establishments
    const establishments = await query(queries.establishmentsForMember, [id], false);

    return establishments;
  } catch (error) {
    console.error(error);
    return undefined;
  }
}

// Invites for member
async function invitesForMember(email) {
  try {
    // Get invites
    const invites = query(queries.invitesForMember, [email], false);

    return invites;
  } catch (error) {
    console.error(error);
    return undefined;
  }
}

// Update invite to accepted
async function updateInviteToAccepted(senderID, inviteeEmail) {
  try {
    // Update invite to accepted
    const success = await query(queries.updateInviteToAccepted, [senderID, inviteeEmail], false);

    return success ? true : false;
  } catch (error) {
    console.error(error);
    return false;
  }
}


// =================
// EXPORT FUNCTIONS
// =================

module.exports = {
  addEstablishment,
  addMember,
  logData,
  establishmentForSessionID,
  establishmentForEmail,
  memberForSessionID,
  memberForEmail,
  establishmentForLogin,
  updateEstablishmentSessionID,
  memberForLogin,
  updateMemberSessionID,
  membersOfEstablishment,
  invitesOfEstablishment,
  existingInvite,
  addInvite,
  withdrawInvite,
  updateMemberMembership,
  establishmentsForMember,
  invitesForMember,
  updateInviteToAccepted
}


// ======================
// QUERY HELPER FUNCTION
// ======================

// Helper function for querying the database
// PARAMETERS
// query: the query string with question marks (?) as placeholders for the parameters
// parameters: an array of parameters, corresponding to the ? placeholders
// singleItem: boolean indicating whether we expect a single item or multiple items
async function query(query, parameters, singleItem) {
  try {
    // Query the database
    let result = await pool.query(query, parameters);
    // We get back an array of two arrays
    // The first array contains the result of our query, so we grab that
    result = result[0];

    // If we expect only one item, get the first (and only) item from the array
    if (singleItem) {
      result = result[0]
    }

    // USED FOR TESTING, TO BE DELETED
    // console.log(`
    // ============= QUERY RESULT =============
    // ${JSON.stringify(result)}
    // ========= END OF QUERY RESULT ==========
    // `);
    // ===============================

    // Return the result
    return result;
  } catch (error) {
    // If there's an error, log it and return undefined
    console.error(error);
    return undefined;
  }
}

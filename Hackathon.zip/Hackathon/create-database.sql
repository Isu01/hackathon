CREATE DATABASE `hackathon` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `hackathon`;

/* Establishments */
CREATE TABLE `establishments` (
  `id` char(5) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(16) NOT NULL,
  `name` varchar(200) NOT NULL,
  `type` varchar(60) NOT NULL,
  `area` int NOT NULL,
  `country` varchar(60) NOT NULL,
  `place` varchar(100) NOT NULL,
  `useswater` tinyint NOT NULL,
  `useselectricity` tinyint NOT NULL,
  `usesgas` tinyint NOT NULL,
  `sessionid` char(36) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/* Members */
CREATE TABLE `members` (
  `id` char(5) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(16) NOT NULL,
  `name` varchar(200) NOT NULL,
  `memberof` varchar(200) NOT NULL,
  `sessionid` char(36) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/* Invites */
CREATE TABLE `invites` (
  `senderid` char(5) NOT NULL,
  `inviteeemail` varchar(100) NOT NULL,
  `sent` tinyint NOT NULL,
  `accepted` tinyint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/* Logs */
CREATE TABLE `logs` (
  `establishmentid` char(5) NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `watertotal` decimal(9,2) NOT NULL,
  `electricitytotal` decimal(9,2) NOT NULL,
  `gastotal` decimal(9,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

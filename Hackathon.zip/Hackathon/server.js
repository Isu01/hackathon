// Import Express
const express = require("express");
// Initialize server instance
const server = express();

// Parse JSON from request body
server.use("/", express.json({ limit: '100mb' }));

// Set up static resources
server.use(express.static("./static"));

// Use authorization
const authorize = require('./authorize');
server.use("/", authorize);

// =============================
// EVERY PATH AND ROUTER
// DATA RELATED PATHS
// PAGES ARE HANDLED IN STATIC
// =============================

// Main route
const mainRouter = require("./routers/main.js");
server.use("/", mainRouter);

// API route
const apiRouter = require("./routers/api.js");
server.use("/api", apiRouter);

// Error handling
server.use((error, request, response, next) => {
  // Log error
  console.error(error);

  // Respond with an error
  return response.status(400).send("Error");
});

// Fallback route
server.use((request, response) => {
  // Respond with not found error
  return response.status(404).send("404 - Not Found");
});


// TEST SETUP
// process.env.SERVER_PORT = 8000;

// Start Server
server.listen(process.env.SERVER_PORT, () => console.log("Server started"));
// MAIN CONTROLLER

// Import path
const path = require("path");

// FUNCTIONS

// Home Page
function home(request, response) {
  return response.status(200).sendFile(path.resolve("home.html"));
}

// Data Page
function data(request, response) {
  // If there is an establishment, send Data Page for establishment
  if (request.establishment) {
    return response.status(200).sendFile(path.resolve("dataest.html"));
  }

  // If there is a member, send Data Page for member
  if (request.member) {
    return response.status(200).sendFile(path.resolve("datamem.html"));
  }

  // Just in case, redirect to login
  return response.redirect("/login");
}

// Register Page
function register(request, response) {
  // Get profile type from url
  const profileType = request.query.profiletype;

  // For establishments
  if (profileType === "establishment") {
    return response.status(200).sendFile(path.resolve("registerest.html"));
  }

  // For members
  if (profileType === "member") {
    return response.status(200).sendFile(path.resolve("registermem.html"));
  }

  // Default
  return response.status(200).sendFile(path.resolve("register.html"));
}

// Login Page
function login(request, response) {
  return response.status(200).sendFile(path.resolve("login.html"));
}


// Export the functions
module.exports = {
  home,
  data,
  register,
  login
}

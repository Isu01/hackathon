// ESTABLISHMENT CONTROLLER

// Import database functions
const database = require("../database.js");

// Import random code function
const randomCode = require("../randomfivedigit.js");

// Import uuid function
const { v4: uuid } = require("uuid");

// FUNCTIONS

// Register
async function register(request, response) {
  // Get values from request body
  const { email, password, name, type, area, country, place, usesWater, usesElectricity, usesGas } = request.body;

  // If any of them is missing, respond with an error
  if (!email || !password || !name || !type || !area || !country || !place || !(usesWater === true || usesWater === false) || !(usesElectricity === true || usesElectricity === false) || !(usesGas === true || usesGas === false)) {
    return response.status(400).json({ success: false, message: "Missing details" });
  }


  // =================================
  // TODO
  // FORMAT TESTING !!!!!!!!!!!!!!
  // =================================


  // If email is in use, respond with an error
  const existingEstablishment = await database.establishmentForEmail(email);
  if (existingEstablishment) {
    return response.status(400).json({ success: false, message: "Email is already in use", emailError: true });
  }

  // Generate session id
  const sessionID = uuid();

  // Add establishment
  const success = await database.addEstablishment(randomCode(), email, password, name, type, area, country, place, usesWater, usesElectricity, usesGas, sessionID);

  // If not success, respond with an error
  if (!success) {
    return response.status(400).json({ success: false, message: "An error occured" });
  }

  // Set cookies
  response.cookie("sessionID", sessionID, { maxAge: 48 * 60 * 60 * 1000 });
  response.cookie("profileType", "establishment", { maxAge: 48 * 60 * 60 * 1000 });

  // Respond with success
  return response.status(201).json({ success: true, message: "Added establishment" });
}

// Login
async function login(request, response) {
  // Get email and password from request body
  const { email, password } = request.body;

  // If any of them is missing, respond with an error
  if (!email || !password) {
    return response.status(400).json({ success: false, message: "Missing details" });
  }

  // Get establishment
  const establishment = await database.establishmentForLogin(email, password);

  // If no establishment, respond with an error
  if (!establishment) {
    return response.status(400).json({ success: false, message: "Incorrect details", unauthorizedError: true });
  }

  // Generate session id
  const sessionID = uuid();

  // Update session id for establishment
  const updatedSessionID = await database.updateEstablishmentSessionID(establishment.id, sessionID);

  // If session id is not updated, respond with an error
  if (!updatedSessionID) {
    return response.status(400).json({ success: false, message: "An error occured" });
  }

  // Set cookies
  response.cookie("sessionID", sessionID, { maxAge: 48 * 60 * 60 * 1000 });
  response.cookie("profileType", "establishment", { maxAge: 48 * 60 * 60 * 1000 });

  // Respond with success
  return response.status(201).json({ success: true, message: "Logged in" });
}

// Log Data
async function logData(request, response) {
  // Get values from request body
  const { totalWater, totalElectricity, totalGas } = request.body;

  const establishment = request.establishment;

  // Check if there are values, but only if the establishment uses that utility
  if ((establishment.usesWater && !totalWater) || (establishment.usesElectricity && !totalElectricity) || (establishment.usesGas && !totalGas)) {
    return response.status(400).json({ success: false, message: "Missing details" });
  }


  // =====================
  // TODO
  // FORMAT CHECK
  // =====================

  // Log data
  const success = await database.logData(establishment.id, totalWater, totalElectricity, totalGas);

  // If not success, respond with an error
  if (!success) {
    return response.status(400).json({ success: false, message: "An error occured" });
  }

  // Respond with success
  return response.status(201).json({ success: true, message: "Added data" });
}

// Get Member Info
async function memberInfo(request, response) {
  const establishment = request.establishment;

  // Get members
  const members = await database.membersOfEstablishment(establishment.id);

  // Get unaccepted invites
  const invites = await database.invitesOfEstablishment(establishment.id);

  // Respond with success
  return response.status(200).json({ success: true, data: { members, invites }});
}

// Handle Members
async function handleMembers(request, response) {
  // Get operations from request body
  const operations = request.body;

  const establishment = request.establishment;

  // If no operations, respond with an error
  if (!operations || Object.keys(operations).length === 0 || operations.length === 0) {
    return response.status(400).json({ success: false, message: "Missing details" });
  }

  // Handle operations
  await Promise.all(operations.map(async (operation) => {

    // ====================
    // TODO
    // FORMAT CHECK EMAIL
    // ====================

    // If invite, add invite log
    if (operation.action === "invite") {
      // Check if invite exists
      const existingInvite = await database.existingInvite(establishment.id, operation.email);
      if (existingInvite) {
        return;
      }

      // Add invite
      await database.addInvite(establishment.id, operation.email);
    }

    // If withdraw, remove invitation
    if (operation.action === "withdraw") {
      // Withdraw invitation
      await database.withdrawInvite(establishment.id, operation.email);
    }

    // If remove, remove member from establishment
    if (operation.action === "remove") {
      // Get member
      const member = await database.memberForEmail(operation.email);
      if (!member) {
        return;
      }

      // Remove member from establishment
      member.membership = member.membership.filter((estid) => estid !== establishment.id);

      // Update member membership
      await database.updateMemberMembership(member.email, member.membership.join("|"));
    }

  }));

  // Respond with success
  return response.status(201).json({ success: true, message: "Operations completed" });
}

// Export the functions
module.exports = {
  register,
  login,
  logData,
  memberInfo,
  handleMembers
}

// MEMBER CONTROLLER

// Import database functions
const database = require("../database.js");

// Import random code function
const randomCode = require("../randomfivedigit.js");

// Import uuid function
const { v4: uuid } = require("uuid");

// FUNCTIONS

// Register
async function register(request, response) {
  // Get values from request body
  const { email, password, name } = request.body;

  // If any of them is missing, respond with an error
  if (!email || !password || !name) {
    return response.status(400).json({ success: false, message: "Missing details" });
  }


  // =================================
  // TODO
  // FORMAT TESTING !!!!!!!!!!!!!!
  // =================================


  // If email is in use, respond with an error
  const existingMember = await database.memberForEmail(email);
  if (existingMember) {
    return response.status(400).json({ success: false, message: "Email is already in use", emailError: true });
  }

  // Generate session id
  const sessionID = uuid();

  // Add member
  const success = await database.addMember(randomCode(), email, password, name, "", sessionID);

  // If not success, respond with error
  if (!success) {
    return response.status(400).json({ success: false, message: "An error occured" });
  }

  // Set cookies
  response.cookie("sessionID", sessionID, { maxAge: 48 * 60 * 60 * 1000 });
  response.cookie("profileType", "member", { maxAge: 48 * 60 * 60 * 1000 });

  // Respond with success
  return response.status(201).json({ success: true, message: "Added member" });
}

// Login
async function login(request, response) {
  // Get email and password from request body
  const { email, password } = request.body;

  // If any of them is missing, respond with an error
  if (!email || !password) {
    return response.status(400).json({ success: false, message: "Missing details" });
  }

  // Get member
  const member = await database.memberForLogin(email, password);

  // If no member, respond with an error
  if (!member) {
    return response.status(400).json({ success: false, message: "Incorrect details", unauthorizedError: true });
  }

  // Generate session id
  const sessionID = uuid();

  // Update session id for member
  const updatedSessionID = await database.updateMemberSessionID(member.id, sessionID);

  // If session id is not updated, respond with an error
  if (!updatedSessionID) {
    return response.status(400).json({ success: false, message: "An error occured" });
  }

  // Set cookies
  response.cookie("sessionID", sessionID, { maxAge: 48 * 60 * 60 * 1000 });
  response.cookie("profileType", "member", { maxAge: 48 * 60 * 60 * 1000 });

  // Respond with success
  return response.status(201).json({ success: true, message: "Logged in" });
}

// Get Membership Info
async function membershipInfo(request, response) {
  const member = request.member;

  // Get establishments
  const establishments = await database.establishmentsForMember(member.id);

  // Get invites
  const invites = await database.invitesForMember(member.email);

  // Respond with success
  return response.status(200).json({ success: true, data: { establishments, invites } });
}

// Handle Memberships
async function handleMemberships(request, response) {
  // Get operations from request body
  const operations = request.body;

  const member = request.member;

  // If no operations, respond with an error
  if (!operations || Object.keys(operations).length === 0 || operations.length === 0) {
    return response.status(400).json({ success: false, message: "Missing details" });
  }

  // Handle operations
  await Promise.all(operations.map(async (operation) => {
    // If accept, update membership
    if (operation.action === "accept") {
      // Check if invitation exists
      const existingInvite = await database.existingInvite(operation.estID, member.email);
      if (!existingInvite) {
        return;
      }
      // Update invitation to be accepted
      await database.updateInviteToAccepted(operation.estID, member.email);
      // Add establishment id
      member.membership.push(operation.estID);
      // Make sure there are no duplicates in membership
      member.membership = [...new Set(member.membership)];
      // Update membership
      await database.updateMemberMembership(member.email, member.membership.join("|"));
    }

    // If leave, update membership
    if (operation.action === "leave") {
      // Remove establishment id
      member.membership = member.membership.filter((estID) => estID !== operation.estID);
      // Update membership
      await database.updateMemberMembership(member.email, member.membership.join("|"));
    }
  }));

  // Respond with success
  return response.status(201).json({ success: true, message: "Operations completed" });
}

// Export the functions
module.exports = {
  register,
  login,
  membershipInfo,
  handleMemberships
}

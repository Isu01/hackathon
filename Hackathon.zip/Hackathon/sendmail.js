// Import nodemailer
const nodemailer = require('nodemailer');

// TEST SETUP
// process.env.MAIL_HOST = "smtp.example.com";
// process.env.MAIL_PORT = 587;
// process.env.MAIL_USER = "noreply@example.com";
// process.env.MAIL_PASS = "password";

// Create transporter
const transporter = nodemailer.createTransport({
  host: process.env.MAIL_HOST,
  port: process.env.MAIL_PORT,
  secure: false,
  auth: {
    user: process.env.MAIL_USER,
    pass: process.env.MAIL_PASS
  },
  tls: {
    rejectUnauthorized: false
  }
});

// Send mail function
async function sendMail(to, subject, text, html) {
  try {
    await transporter.sendMail({
      from: 'noreply@lukaisu.hu',
      to: to,
      subject: subject,
      text: `${text}`,
      html: `${html}`
    });

    return true;
  } catch (error) {
    console.error(error);
    return false;
  }
}

// Export function
module.exports = sendMail;